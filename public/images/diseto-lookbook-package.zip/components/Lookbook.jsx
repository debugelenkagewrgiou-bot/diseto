"use client";

import { useMemo, useState } from "react";

const projects = [
  { src: "/images/lookbook/kitchen-01.jpg", category: "KITCHENS", title: "Kitchen design 01", size: "wide" },
  { src: "/images/lookbook/kitchen-02.jpg", category: "KITCHENS", title: "Kitchen design 02", size: "tall" },
  { src: "/images/lookbook/kitchen-03.jpg", category: "KITCHENS", title: "Kitchen design 03", size: "normal" },
  { src: "/images/lookbook/kitchen-04.jpg", category: "KITCHENS", title: "Kitchen design 04", size: "wide" },
  { src: "/images/lookbook/kitchen-05.jpg", category: "KITCHENS", title: "Kitchen design 05", size: "normal" },
  { src: "/images/lookbook/kitchen-06.jpg", category: "KITCHENS", title: "Kitchen design 06", size: "wide" },
  { src: "/images/lookbook/kitchen-07.jpg", category: "KITCHENS", title: "Kitchen design 07", size: "normal" },
  { src: "/images/lookbook/kitchen-08.jpg", category: "KITCHENS", title: "Kitchen design 08", size: "wide" },
  { src: "/images/lookbook/commercial-01.jpg", category: "COMMERCIAL", title: "Commercial space 01", size: "wide" },
  { src: "/images/lookbook/wardrobe-01.jpg", category: "WARDROBES", title: "Wardrobe design 01", size: "normal" },
  { src: "/images/lookbook/kitchen-09.jpg", category: "KITCHENS", title: "Kitchen design 09", size: "wide" },
  { src: "/images/lookbook/wardrobe-02.jpg", category: "WARDROBES", title: "Wardrobe design 02", size: "normal" },
  { src: "/images/lookbook/kitchen-10.jpg", category: "KITCHENS", title: "Kitchen design 10", size: "wide" },
];

const filters = ["ALL", "KITCHENS", "WARDROBES", "COMMERCIAL"];

export default function Lookbook() {
  const [activeFilter, setActiveFilter] = useState("ALL");
  const [selected, setSelected] = useState(null);

  const visibleProjects = useMemo(
    () => activeFilter === "ALL"
      ? projects
      : projects.filter((project) => project.category === activeFilter),
    [activeFilter]
  );

  return (
    <section className="diseto-lookbook" id="lookbook">
      <div className="lookbook-inner">
        <div className="lookbook-heading">
          <div>
            <span className="lookbook-kicker">DISETO — SELECTED WORKS</span>
            <h2>THE <em>LOOKBOOK</em></h2>
          </div>
          <p>Spaces shaped around the way we live.</p>
        </div>

        <div className="lookbook-toolbar">
          <span className="lookbook-count">A COLLECTION OF OUR WORK</span>
          <div className="lookbook-filters" aria-label="Filter projects">
            {filters.map((filter) => (
              <button
                key={filter}
                type="button"
                className={activeFilter === filter ? "active" : ""}
                onClick={() => setActiveFilter(filter)}
                aria-pressed={activeFilter === filter}
              >
                {filter}
              </button>
            ))}
          </div>
        </div>

        <div className="lookbook-grid">
          {visibleProjects.map((project, index) => (
            <button
              className={`lookbook-card ${project.size}`}
              key={project.src}
              type="button"
              onClick={() => setSelected(project)}
              aria-label={`View ${project.title}`}
            >
              <img src={project.src} alt={`${project.category.toLowerCase()} by DiSeto`} loading={index < 4 ? "eager" : "lazy"} />
              <span className="lookbook-card-caption">
                <span>{project.category}</span>
                <span>{String(index + 1).padStart(2, "0")} ↗</span>
              </span>
            </button>
          ))}
        </div>

        <div className="lookbook-cta">
          <div>
            <span className="lookbook-kicker">HAVE A PROJECT IN MIND?</span>
            <p>Let’s create a space that feels like yours.</p>
          </div>
          <a href="/#contact">DISCUSS YOUR PROJECT <span>↗</span></a>
        </div>
      </div>

      {selected && (
        <div className="lookbook-lightbox" role="dialog" aria-modal="true" aria-label="Project image" onClick={() => setSelected(null)}>
          <button className="lookbook-close" type="button" onClick={() => setSelected(null)} aria-label="Close image">×</button>
          <img src={selected.src} alt={`${selected.category.toLowerCase()} by DiSeto`} onClick={(event) => event.stopPropagation()} />
          <span>{selected.category} — {selected.title}</span>
        </div>
      )}

      <style jsx>{`
        .diseto-lookbook { background:#f7f4ed; color:#28231e; padding:120px 7%; }
        .lookbook-inner { max-width:1440px; margin:0 auto; }
        .lookbook-heading { display:flex; justify-content:space-between; align-items:flex-end; gap:30px; margin-bottom:72px; }
        .lookbook-kicker,.lookbook-count { display:block; color:#928875; font:500 9px/1.5 Arial,sans-serif; letter-spacing:2px; }
        .lookbook-heading h2 { margin:20px 0 0; font:400 clamp(48px,8vw,104px)/.95 Georgia,serif; letter-spacing:-.065em; }
        .lookbook-heading h2 em { color:#a89576; font-weight:400; }
        .lookbook-heading p { max-width:220px; margin:0 0 8px; color:#777168; font:13px/1.7 Arial,sans-serif; }
        .lookbook-toolbar { display:flex; justify-content:space-between; align-items:center; gap:20px; padding:18px 0; border-top:1px solid #dcd6ca; border-bottom:1px solid #dcd6ca; margin-bottom:28px; }
        .lookbook-filters { display:flex; flex-wrap:wrap; gap:8px 24px; }
        .lookbook-filters button { padding:5px 0; border:0; background:transparent; color:#777168; font:500 9px Arial,sans-serif; letter-spacing:1.5px; cursor:pointer; }
        .lookbook-filters button.active { color:#28231e; border-bottom:1px solid #a89576; }
        .lookbook-grid { display:grid; grid-template-columns:repeat(12,minmax(0,1fr)); grid-auto-flow:dense; gap:18px; align-items:start; }
        .lookbook-card { position:relative; display:block; grid-column:span 6; width:100%; padding:0; border:0; background:#e8e3d9; text-align:left; cursor:zoom-in; overflow:hidden; }
        .lookbook-card.wide { grid-column:span 8; }
        .lookbook-card.tall { grid-column:span 4; }
        .lookbook-card.normal { grid-column:span 6; }
        .lookbook-card img { display:block; width:100%; height:clamp(260px,38vw,520px); object-fit:cover; transition:transform .7s cubic-bezier(.2,.7,.2,1); }
        .lookbook-card.tall img { height:clamp(320px,48vw,620px); }
        .lookbook-card:hover img { transform:scale(1.035); }
        .lookbook-card-caption { display:flex; justify-content:space-between; padding:13px 2px 3px; color:#777168; font:9px Arial,sans-serif; letter-spacing:1.5px; }
        .lookbook-cta { display:flex; justify-content:space-between; align-items:center; gap:25px; margin-top:100px; padding-top:28px; border-top:1px solid #dcd6ca; }
        .lookbook-cta p { margin:10px 0 0; font:clamp(22px,3vw,34px) Georgia,serif; }
        .lookbook-cta a { display:inline-flex; align-items:center; gap:28px; padding:19px 22px; background:#28231e; color:#f7f4ed; text-decoration:none; font:500 9px Arial,sans-serif; letter-spacing:1.5px; transition:background .25s; }
        .lookbook-cta a:hover { background:#a89576; }
        .lookbook-lightbox { position:fixed; inset:0; z-index:100000; display:flex; flex-direction:column; justify-content:center; align-items:center; gap:15px; padding:5vw; background:rgba(20,18,16,.96); color:#f7f4ed; }
        .lookbook-lightbox img { max-width:92vw; max-height:82vh; object-fit:contain; }
        .lookbook-lightbox span { font:10px Arial,sans-serif; letter-spacing:2px; }
        .lookbook-close { position:absolute; top:22px; right:30px; border:0; background:transparent; color:white; font:40px Arial,sans-serif; cursor:pointer; }
        @media(max-width:700px) {
          .diseto-lookbook { padding:82px 6%; }
          .lookbook-heading { display:block; margin-bottom:42px; }
          .lookbook-heading p { margin-top:20px; }
          .lookbook-toolbar { display:block; }
          .lookbook-filters { margin-top:16px; gap:8px 17px; }
          .lookbook-grid { grid-template-columns:repeat(2,minmax(0,1fr)); gap:20px 10px; }
          .lookbook-card,.lookbook-card.wide,.lookbook-card.tall,.lookbook-card.normal { grid-column:span 1; }
          .lookbook-card:nth-child(3n + 1) { grid-column:span 2; }
          .lookbook-card img,.lookbook-card.tall img { height:clamp(190px,62vw,340px); }
          .lookbook-cta { display:block; margin-top:65px; }
          .lookbook-cta a { margin-top:25px; }
        }
        @media(prefers-reduced-motion:reduce) {
          .lookbook-card img { transition:none; }
        }
      `}</style>
    </section>
  );
}
